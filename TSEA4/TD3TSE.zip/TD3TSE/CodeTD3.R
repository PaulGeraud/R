install.packages("TSA")
library(tidyverse)
library(ggforce)
library(gridExtra)
library(TSstudio)
library(lubridate)
library(TSA)
library(forecast)
library(datasets)
#Ex 2
n=200
BBG=rnorm(n)
Y_exp = arima.sim(model=list(order=c(1,0,1), ma=c(0.5), ar=c(4)), n=n) #ne marche pas avec les modèles non stationnaires
Y_exp=rep(0,n)
for (i in 2:n)
{
  Y_exp[i]=1.05*Y_exp[i-1]+BBG[i]+0.5*BBG[i-1]
}
data.frame(Date=c(1:n),Valeur=Y_exp)%>%
  ggplot(aes(x=Date,y=Valeur))+geom_line(col='black')+
  labs(title="Evolution d'un ARMA(1,1) explosif")
#Montrer que c'est pas stationnaire
#acf
par(mfrow = c(3, 1))
acf(Y_exp,type="covariance", lag.max=24,
    main="Fonction d'autocovariance")
acf(Y_exp,type="correlation", lag.max=24,
    main="Fonction d'autocorrélation")
acf(Y_exp,type="partial", lag.max=24,
    main="Fonction d'autocorrélation partielle")
#persistence de la mémoire
#test de Ljung-Box
lags=c(1:50)
pvals=rep(0,50)
for (i in lags)
{
  pvals=Box.test(Y_exp,lag=i,type="Ljung-Box")$p.value
}
data.frame(MaxLag = lags, PVal = pvals)%>%
  ggplot(aes(x=MaxLag,y=PVal))+geom_point(col='red')+
  geom_abline(intercept=0.05,slope=0,col='black',linetype="dashed")+
  labs(title="Test de Ljung-Box pour les 50 pemiers retards")
#graphe cercle unitaire
Roots_AM=polyroot(c(1,0.5))
Roots_AR=polyroot(c(1,-1.05))

data.frame(ReAM=Re(Roots_AM),ImAM=Im(Roots_AM),ReAR=Re(Roots_AR),ImAR=Im(Roots_AR))%>%
  ggplot()+geom_point(aes(x=ReAM,y=ImAM,color="AM"),size=3)+geom_point(aes(x=ReAR,y=ImAR,color="AR"),size=3)+
  geom_circle(aes(x0 = 0,y0=0,r=1),col="black")+
  geom_hline(yintercept = 0)+geom_vline(xintercept = 0)+
  xlim(c(-2,2))+ylim(c(-2,2))+
  scale_color_manual(values = c("AM" = "red", "AR" = "blue"), 
                     labels = c("AM" = "Racines polynôme AM", "AR" = "Racines polynôme AR")) +
  labs(title = "Graphe des racines du polynôme caractéristique par rapport au cercle unité") +
  guides(color = guide_legend(title = "Légende"))
#processus inversible mais non stationnaire

#test de Dickey-FUller
#H0:présence d'une racine unitaire partie AR
#H1: Stationnarité du processus AR
adf.test(Y_exp)
#Pval proche de 1, on conserve H0=> racine unitaire probable
#test de McLeod-Li
#H0: pas d'effet ARCH
#H1: présence effet ARCH
McL=McLeod.Li.test(y=Y_exp,plot=FALSE)$p.values
data.frame(lags=c(1:23),pvals=McL)%>%
  ggplot(aes(x=lags,y=pvals))+geom_point(col='red')+
  geom_abline(intercept=0.05,slope=0,col='black',linetype="dashed")+
  labs(title="Test de McLeod&Li pour les 23 pemiers retards")
#On rejette H0. Présence d'effet ARCH (hétéroscédasticité en fct du temps)

#forecast
model = auto.arima(Y_exp) #fit le meilleur modele arima possible basé sur le AIC
myforecast = forecast(model, level=c(95), h=1200)
plot(myforecast)
#--------------------------------------------------------------------------------------------------------------------------------------------------
#Ex3
transportation=read.csv("transportation_indexEx3.csv",sep=";",header=T)%>%
  mutate(X=as.POSIXct(X,format="%d/%m/%Y"))%>%
  rename(Date=X)

TruncTransportation=transportation%>%
  filter(Date<"2019-12-01")
View(transportation)
#En passant par TSstudio
date=as.Date(transportation$Date)
Serv=transportation$USTRASERV
Frei=transportation$USTRAFREI
Pass=transportation$USTRAPASS
data_tps=transportation[,-1] #remove first column
data_tps=ts(data_tps,start=c(2000,1),frequency=12) #création série temp
#On tronque la série pour éviter la période covid
data_covid=window(data_tps,start=c(2000,1),end=c(2019,12))
#plot sur un même graph
Data_covid_df=as.data.frame(data_covid) #pour pouvoir utiliser mathplot
x11()
matplot(Data_covid_df,type="l")


x11()
TruncTransportation%>%
  ggplot(aes(x=Date))+geom_line(aes(y=USTRASERV),col='red')+
  geom_line(aes(y=USTRAFREI),col='blue')+geom_line(aes(y=USTRAPASS),col='orange')+
  labs(y="count",title="Evolution of transportation service before COVID19")

acf(data_covid[,3],lag.max=50)
Box.test(data_covid[,3],30)
#Box pierce is asymptotic, so it is worse that LjungBox for small data samples
#pas modelisable, non stationnarité du moment d'ordre 1, en revanche, moment d'ordre 2 semble plutôt constant
pacf(data_covid[,3],lag.max=50)
#1ere autocorrel très forte, on a affaire donc affaire à un AR(1), avec coeff=1 => MARCHE ALEATOIRE=>NON STATIONNAIRE

#Comment stationnariser la série ?
#1: Supposer que il y a une tendance linéaire
#2: Appliquer un filtre en différence de la série
#Pour choisir entre les deux, faire un test de y_t -y_t^hat et de regarder si elle est stationnaire. En l'occurence vu que c'est un AR(1)
#On va prendre le filtre en différence 


#Step 2
NyBirths=scan("http://robjhyndman.com/tsdldata/data/nybirths.dat")
Fancy=scan("http://robjhyndman.com/tsdldata/data/fancy.dat")
tsNyBirths=ts(NyBirths,start=c(1949,1),freq=12)
tsFancy=ts(Fancy,start=c(1987,1),freq=12)
ts_plot(tsNyBirths) #Schémas additif: augment autour d'une tendance, amplitude constante. Non stationnaire en plus
ts_plot(tsFancy) #schéma multiplicatif: l'amplitude des pics de saiso augmente
x11()
par(mfrow=c(2,1))
acf(tsNyBirths,lag.max=50) #décroit et remonte toujours toutes les 12 périodes=>périodicté. Bcp de mémoire
acf(tsFancy,lag.max=50)#décroit bcp + rapides et des pics d'ACF

#Ex 4 : régression
#indicatrice pour Births
for(i in 1:12)
{
  SU=rep(0,12)
  SU[i]=1
  S=rep(SU,14) #12*14=168
  assign(paste("s",i,sep=""),S)
}
#indicatrice pour Fancy
for(i in 1:12)
{
  SU=rep(0,12)
  SU[i]=1
  S=rep(SU,7) #12*7=85
  assign(paste("s",i,sep=""),S)
}
dum=cbind(s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12)
basedum=as.data.frame(dum)
model.saiso=lm(NyBirths~dum+0,data=basedum) #le +0 permet d'enlever la constante. Il reste le prblm de non stationnarité
trd=1:length(NyBirths)
newbase=cbind(dum,trd)
basereg=as.data.frame(newbase)
model_trd.saiso=lm(NyBirths~dum+trd+0,data=basereg)
model_trd.saiso$fitted.values
residual=NyBirths-model_trd.saiso$fitted.values
ts_res=ts(residual,start=c(1949,1),freq=12)
ts_plot(ts_res)
acf(ts_res,lag.max=50)

#Ex 5 moving average
births_sa=decompose(tsNyBirths)
plot(births_sa)
#observed: graph classique= Y_t
#trend: la tendance =Y_t-Y^_t
#seasonal: les tendances saiso =Sf
#random: random =epsilon^
#observed=trend+seasonal+random

#Ex 6
#en loadant un dataset externe
data(MLCO2, package = "atsalibrary")
co2= MLCO2
co2 = ts(data = co2$ppm, frequency = 12, start = c(co2[1, "year"], co2[1, "month"]))
#avec dataset de base (moins de valeurs
data(co2)
ts_plot(co2) #on observe une tendance linéaire ainsi qu'une saisonalité additive

x11()
par(mfrow = c(3, 1))
acf(co2,type="covariance", lag.max=60,
    main="Fonction d'autocovariance")
acf(co2,type="correlation", lag.max=60,
    main="Fonction d'autocorrélation")
acf(co2,type="partial", lag.max=60,
    main="Fonction d'autocorrélation partielle")
#filtre en différence
DiffedCo2=diff(x=co2,lag=12,differences = 1)
ts_plot(DiffedCo2)
x11()
par(mfrow = c(3, 1))
acf(DiffedCo2,type="covariance", lag.max=60,
    main="Fonction d'autocovariance")
acf(DiffedCo2,type="correlation", lag.max=60,
    main="Fonction d'autocorrélation")
acf(DiffedCo2,type="partial", lag.max=60,
    main="Fonction d'autocorrélation partielle")
#La tendance linéaire est éliminée mais il reste les pics de saisonalité
DiffedCo2=diff(x=co2,lag=12,differences = 2)
ts_plot(DiffedCo2)
x11()
par(mfrow = c(3, 1))
acf(DiffedCo2,type="covariance", lag.max=60,
    main="Fonction d'autocovariance")
acf(DiffedCo2,type="correlation", lag.max=60,
    main="Fonction d'autocorrélation")
acf(DiffedCo2,type="partial", lag.max=60,
    main="Fonction d'autocorrélation partielle")
#Appliquer un filtre de diff d'ordre 2 centre et enlève les pics de saiso
#Ex 7
#package arima.sim, notamment pour estimer l'ordre de ARMA(p,q)
#Pour choisir le modèle, on argumente, prendre tous les modèles et réaliser des tests sur les résidus notamment
#Question 10: Sans tout refaire, juste tracer la série, argumenter sur le résultat attendu

#Ex 8
#ARMA sur le log(rendement_close) du S&P 500 du 1er janv 2023 à ajd. 
#La réponse peut être NON, encore une fois il faut argumenter (auto corrél dans les rendements ?), pas sûr
#La crise déclenche auto correl aux rendements. 