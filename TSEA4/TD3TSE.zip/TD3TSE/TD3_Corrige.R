# TD3
# Exercice 2 - Explosive processes
# 1 - Simulation d'un processus explosif

install.packages("Metrics")
install.packages("aTSA")
n = 300
wn = rnorm(n, 0, 1)
expl = wn[1:2]

for(i in 3:n){
  expl[i] = expl[i - 1]*1.1 + wn[i]
}

# Graphs (pour voir)
plot(expl, type="l", col="green", main="expl")
acf(expl, lag = 20, type = "covariance")
acf(expl, lag = 20, type = "correlation")
pacf(expl, lag = 20)

# 2 - Test
library(forecast)
library(tseries)
library(stats)

  # 1 - Dickey-Fuller test
  adf.test(expl)
    # P-value 0.99 > 0.05 on ne peut rejeter l'hyp. nulle, présence d'une racine unitaire

  # 2 - Kwiatkowski-Phillips-Schmidt-Shin test 
  kpss.test(expl)
    # P-value 0.01 < 0.05 on rejette l'hyp. nulle, le processus n'est pas stationnaire
  
  # 3 - Philips perron test
  PP.test(expl)
    # P-value 0.99 > 0.05 on ne peut rejeter l'hyp. nulle, présence d'une racine unitaire
  
# 3 - Forecast
model = auto.arima(expl)
myforecast = forecast(model, level=c(95), h=1200)
plot(myforecast)

# Partie 2 - Exercice 3 - US Producers Price Index
# 1 - Data load
data_ppi=read.csv("/Users/ugo/Desktop/ESILV2023/usppi.csv",sep=',')
values <- data_ppi[, -1] #delete the header
ppi_tseries <- ts(values,start=c(1974,1),end=c(2022,9),frequency=12) 
plot(ppi_tseries, type="l", col="green", main="US PPI")

# On ne peut modeliser que des series stationnaires -> test adf (par exemple)
adf.test(ppi_tseries)
  # P-value 0.4116 > 0.05 -> non rejet hyp nulle -> racine unitaire -> pas stationnaire
  # On ne peut donc pas modeliser la serie en l'etat

# 2 - Taux de croissance mensuel entre janvier 1981 et decembre 2021
shorter_ppi_ts <- ts(ppi_tseries,start=c(1981,1),end=c(2021,12),frequency=12)
mg_rate = matrix(0,length(shorter_ppi_ts))
for(i in 1:length(shorter_ppi_ts)){
  mg_rate[i-1] = (shorter_ppi_ts[i]/shorter_ppi_ts[i-1]-1)
}

shorter_ppi_ts_gw <- ts(mg_rate,start=c(1981,1),end=c(2021,12),frequency=12)
plot(shorter_ppi_ts_gw,col="blue")

adf.test(shorter_ppi_ts_gw)
  # P-value 0.01 < 0.05 -> rejet hyp nulle -> pas de racine unitaire -> stationnaire
  # On peut donc a present modeliser la serie

# 3 - Identification
acf(shorter_ppi_ts_gw,type = 'correlation',plot=TRUE,main="ACF of ppi", lag=20)
pacf(shorter_ppi_ts_gw,plot=TRUE,main="PACF of ppi", lag=20)
  
  # Decroissance lente sur l'ACF -> AR, PACF -> AR(1)

# 4 - Critere d'information
library(stats)

# matrix of values
lik = matrix(0,4,4)
aic = matrix(0,4,4)
bic = matrix(0,4,4)

# Computation of the Akaike and the Bayesian information criteria for all the couple p and q
for (i in 0:4){
  for (j in 0:4){
    mdl2 = arima(shorter_ppi_ts_gw, order = c(i,0,j))
    lik[i,j] = mdl2$loglik
    aic[i,j] = mdl2$aic
    bic[i,j] = BIC(mdl2)
  }
}

aic
which(aic==min(aic),arr.ind=T)
  # 4,2

bic
which(bic==min(bic),arr.ind=T)
  # 1,1
  # On selectionne la specification la plus parcimonieuse en cas de modèles concurents


# 5 - non, mais c'est souvent le cas. Lecrture graphique n'est pas si fiable, on a plus confiance dans l'approche
# par les criteres d'information

# 6 - Estimation
mdl=arima(shorter_ppi_ts_gw,order=c(1,0,1))
mdl
coef(mdl)

mdl_res=residuals(mdl) #estimated residuals
plot(mdl_res)

yt_hat = lag(shorter_ppi_ts_gw, k = 1)*mdl$coef[1]
  
# 7 - Plot
matplot(cbind(shorter_ppi_ts_gw,yt_hat)[300:nrow(cbind(shorter_ppi_ts_gw,yt_hat)),],type = 'l')

#significance
# statistic test
stat_test = mdl$coef/sqrt(diag(mdl$var.coef)) 
stat_test

# p_value
stat_pval = 2*(1-pt(abs(stat_test),mdl$nobs-length(mdl$coef)))
stat_pval

# If the p_value is inferior to 0.05 then the coefficient is significant, else we can’t 
# conclude because the value could be null. Here the p_value of AR1 and the intercept is below 
# 0.05 so they are significant but the p_value of MA1 is above so MA1 is not significant.

# So our model is pretty good but we don’t know if it’s the best to infer the behavior of the inflation dynamics.
# Also, we should get rid of the MA term, given its coef is not significantly different from 0.

# Quality checks
library(Metrics)
library(stats)
library(tseries)
library(lmtest)
library(aTSA)
# residual study:
# R^2 and R^2 ajust? of the model
RMSE=rmse(shorter_ppi_ts_gw,mdl)
RMSE

R2=1-(sum(mdl_res)/var(mdl_res))
R2

R2adj=1-((length(mdl_res)-1)/(length(mdl_res)-1-2))*sum(mdl_res)/var(mdl_res)
R2adj

# Distribution of the residuals -> to check normality
hist(mdl_res)

# Normality of the distribution 
jarque.bera.test(mdl_res) #JB test

# the normality of the residual distribution is verified
shapiro.test(mdl_res)  #shapiro test 

# Independence 
Box.test(mdl_res, lag = 10, type = "Ljung")

# heteroscedasticity of the residuals
arch.test(mdl)

# 9 - Forecast
library(forecast)
predict1 = forecast(mdl, h = 1)
predict2 = forecast(mdl, h = 2)
predict3 = forecast(mdl, h = 3)
par(mfrow=c(3,1))
plot(predict1,xlim=c(2018,2022))
plot(predict2,xlim=c(2018,2022))
plot(predict3,xlim=c(2018,2022))
