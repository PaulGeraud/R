library(tidyverse)
library(ggforce)
library(gridExtra)
library(plotly)
#Exercice 1 , Box Muller
set.seed(1898)
Box_Muller=function(n)
{
  U_1=runif(n,0,1)
  U_2=runif(n,0,1)
  R=-2*log(U_1) #simule loi exponentielle
  Theta=2*pi*U_2 #simule unif sur (0,2pi)
  return(data.frame(N_1=sqrt(R)*cos(Theta),N_2=sqrt(R)*sin(Theta)))
}

n=100000
N=Box_Muller(n)

N%>%
  ggplot(aes(x=N_1,y=N_2))+geom_point()+
  labs(title="Résultat en 2D")

#diagnostics que ce sont bien des lois normales
p1=N%>%
    ggplot(aes(x=N_1))+geom_histogram(fill="lightblue",col="black",bins = sqrt(n))+
  labs(title="Histogramme de la 1ere loi normale marginale")
p2=N%>%
    ggplot(aes(x=N_2))+geom_histogram(fill="pink",col="black",bins= sqrn(n))+
  labs(title="Histogramme de la 2eme loi normale marginale")
p3=N%>%
  ggplot(aes(sample=N_1))+stat_qq(col="lightblue")+
  geom_abline(intercept=0,slope=1)+
  labs(title="QQplot de la 1ere loi normale marginale")
p4=N%>%
  ggplot(aes(sample=N_2))+stat_qq(col="pink")+
  geom_abline(intercept=0,slope=1)+
  labs(title="QQplot de la 2eme loi normale marginale")
x11()
grid.arrange(p1,p2,p3,p4,nrow=2,ncol=2)

ks.test(N$N_1,"pnorm")
ks.test(N$N_2,"pnorm")

#Box Muller modifié

Box_Muller_Mod=function(n)
{
  
}
