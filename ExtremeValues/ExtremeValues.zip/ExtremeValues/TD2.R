library(evir)
#install.packages("moments")
#library(moments)
install.packages("e1071")
library(e1071)
n=10^6 #nombres de points générés
N=1000 #nombres de blocs
X=rgev(n,xi=0.5,mu=100,sigma=50)
#X=rexp(n)
#X=rgamma(n,shape=5)
#X=rnorm(n)
#X=runif(n,0,1)
sampled=matrix(X,ncol=N,byrow = TRUE)
#3.1

x11()
boxplot(sampled[1,])
hist(X,breaks=sqrt(n),xlim=c(0,3000))
#3.2
summary(X) #médiane<moyenne=> asymétrie à gauche, skewness positif
sd(X)
skewness(X) #=0, symétrie, positif, plus de valeurs à gauche, né
kurtosis(X)
#3.3 & 3.4
max_sampled=apply(sampled,1,max)
x11()
boxplot(max_sampled)
plot(max_sampled)
hist(max_sampled,breaks=32)
#3.5
summary(max_sampled) #médiane<moyenne=> asymétrie à gauche, skewness positif
sd(max_sampled)
skewness(max_sampled)
kurtosis(max_sampled)
#3.6
par(mfrow=c(2,1))
h1=hill(max_sampled,option="alpha")
h2=hill(max_sampled,option="xi")
#3.7
Model_GEV=gev(X,N)
summary(Model_GEV)