#Ex1
Notes=c(rep(7,5),rep(9,4),rep(11,21),rep(12,35),rep(13,32),rep(15,3))
#1
moyenne=mean(Notes)
#2
Q1=quantile(Notes,0.25)
medianne=median(Notes)
Q3=quantile(Notes,0.75)
#3
var=var(Notes)
sd=sd(Notes)
#4
Notes2=Notes+1
moyenne=mean(Notes2)
Q1=quantile(Notes2,0.25)
medianne=median(Notes2)
Q3=quantile(Notes2,0.75)
var=var(Notes2)
sd=sd(Notes2)
#5
Notes3=Notes*1.1
moyenne=mean(Notes3)
Q1=quantile(Notes3,0.25)
medianne=median(Notes3)
Q3=quantile(Notes3,0.75)
var=var(Notes3)
sd=sd(Notes3)

summary(Notes)

#Ex2

portfolio=100000
expected_shortfall_pct=6

expected_shortfall_amount=portfolio*expected_shortfall_pct/100

#Ex3

Amounts=c(10^7,10^6)
proba=c(0.009,0.991)
confLvl=0.99
#VaR
VaR=Amounts*qnorm(1-confLvl,proba,sqrt(proba*(1-proba)))
expected_shortfall=Amounts*(1-pnorm(qnorm(1-confLvl,proba,sqrt(proba))))/confLvl

#5
confLvl=0.99
mean=0.1
sd=0.2
z_score=qnorm(1-(1-confLvl)/2)
VaR=mean+z_score*sd
#VaR=qnorm(1-(1-confLvl)/2,mean,sd)
VaR_stock=100*exp(VaR)

#ex 7
library(evir)
confLvl=0.99
xi=1/3
mu=100
sigma=100
#generate 1000 numbers with pareto
sample=rgpd(1000,xi,mu,sigma)
quantile=qgpd(1-confLvl,xi,mu,sigma)
#ES
ES=mean(sample[sample>quantile])